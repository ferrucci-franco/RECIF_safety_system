%% PLOT figures for article

%% cleanup
close all

%% Data extraction
t = out.logsout.getElement('Xgas (% of LFL)').Values.Time;
t = seconds(t);
%
Xgas_LFL = out.logsout.getElement('Xgas (% of LFL)').Values.Data;
alarm_LFL = out.logsout.getElement('alarm (% of LFL)').Values.Data;
%
dVextr = out.logsout.getElement('d(Vextr)/dt (m3/h)').Values.Data;
%
dVdt_in_Nl_min = out.logsout.getElement('d(Vg,in)/dt (Normal litre/min)').Values.Data;
dVdt_out_Nl_min = out.logsout.getElement('d(m gas,out)/dt (Normal litre/min)').Values.Data;
%
dMdt_in_kg_sec = out.logsout.getElement('d(m,in)/dt (kg/s)').Values.Data;
dMdt_out_kg_sec = out.logsout.getElement('d(m gas,out)/dt (kg/s)').Values.Data;
dMdt_electr_kg_sec = out.logsout.getElement('dm/dt electr. (kg/s)').Values.Data;
%
dMdt_in_ukg_sec = dMdt_in_kg_sec*1e6;
dMdt_out_ukg_sec = dMdt_out_kg_sec*1e6;
dMdt_electr_ukg_sec = dMdt_electr_kg_sec*1e6;
%
% P_bar = out.logsout.getElement('P (bar)').Values.Data;

%% Figure creation
% Some common properties:
lw = 2; % Linewidth

% Time shift:
% t0_sec = 48.3;
% t0_min = t0_sec*c.sec_to_min;
% t_min = t_min - t0_min;

% Time end:
Xend = 6.5*60;
Xticks = seconds(0:30:Xend);

% New figure:
fig = figure(1);
% ---------------------------------------
% Subplot 1:
ax(1) = subplot(311);
plot(t,dMdt_in_ukg_sec,'Linewidth',lw)
ylabel({'H_2 release rate','[10^-^6 kg/s]'},'FontSize',12,'FontWeight','bold','Color','k')
grid on
hold on
plot(t,dMdt_out_ukg_sec,'Linewidth',lw)
plot(t,dMdt_electr_ukg_sec,'Linewidth',lw)
legend('H_2 into the container',...
       'H_2 out of the container',...
       'H_2 production',...
       'FontSize',10)
xticks(Xticks)
Ytick = 0:25:75;
yticks(Ytick);
xtickformat("mm:ss")

% Define new axis with another units:
Ystart = -10;
Yend = 75.5;
ylim([Ystart Yend])
xlim([0 seconds(Xend)])
yyaxis right
ylim([Ystart*kg_sec_to_Nlitre_min*1e-6 Yend*kg_sec_to_Nlitre_min*1e-6])
ylabel('[N.l/min]','FontSize',12,'FontWeight','bold','Color','k')
% Adjust ticks so as the Y grids to coincide (left and right):
ax(1).YColor = [0.6353, 0.0784, 0.1843];
yticks(round(Ytick*kg_sec_to_Nlitre_min*1e-6*1)/1); 

% ---------------------------------------
% Subplot 2:
ax(2) = subplot(312);
plot(t,dVextr,'Linewidth',lw)
ylabel({'Ventilation flow rate','[m^3/h]'},'FontSize',12,'FontWeight','bold','Color','k')
grid on
xticks(Xticks)
xtickformat("mm:ss")

% Define new axis with another units:
Ystart = 300;
Yend = 2500;
ylim([Ystart Yend])
xlim([0 seconds(Xend)])
Ytick = 400:400:2500;
yticks(Ytick); 

yyaxis right
ylim([Ystart/V_container_m3 Yend/V_container_m3])
ylabel('[Air changes per hour]','FontSize',12,'FontWeight','bold','Color','k')
ax(2).YColor = [0.6353, 0.0784, 0.1843];
% Adjust ticks so as the Y grids to coincide (left and right):
yticks(round(Ytick/V_container_m3*1)/1); 

% ---------------------------------------
% Subplot 3:
ax(3) = subplot(313);
plot(t,Xgas_LFL,'Linewidth',lw)
ylabel({'H_2 concentration','[% of LFL]'},'FontSize',12,'FontWeight','bold','Color','k')
grid on
hold on
plot(t,alarm_H2_threshold_percent*ones(size(t)),'Linewidth',lw)
legend('H_2 concentration','Alarm level','FontSize',10)
xlabel('Time [mm:ss]','FontSize',12,'FontWeight','bold','Color','k')
xticks(Xticks)
xtickformat("mm:ss")
xlim([0 seconds(Xend)])

% Define new axis with another units:
Ystart = -1;
Yend = 12;
ylim([Ystart Yend])
Ytick = 0:2:12;
yticks(Ytick); 

yyaxis right
ylim([Ystart/(1/LIE_H2_vol_vol) Yend/(1/LIE_H2_vol_vol)])
ylabel('[vol/vol %]','FontSize',12,'FontWeight','bold','Color','k')
ax(3).YColor = [0.6353, 0.0784, 0.1843];
% Adjust ticks so as the Y grids to coincide (left and right):
yticks(Ytick/(1/LIE_H2_vol_vol)); 

% Tight figure:
% tightfig
