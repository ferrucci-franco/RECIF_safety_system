%% HYDROGEN LEAK
% This script accompanies the work titled:
%
% Design and implementation of the safety system of a solar-driven 
% smart micro-grid comprising hydrogen production for electricity 
%                   & cooling co-generation 
%
% To run the simulations, follow these steps:
%  1. Run this script.
%  2. Run the Simulink file (either leak_electrolyzer_sim.slx or
%     leak_fuel_cell_sim)
%  3. Run the scrip to plot the results (either
%     leak_electr_plot_article.slx or leak_fuel_cell_plot_article.slx)
%
%
% Franco Ferrucci
% University of French Polynesia
% franco.ferrucci@upf.pf
% June 2023

%% Cleanup
close all
clear
clc

%% Parameters
% Conversion factors:
c = conversion_factors(); % conversion_factors.m must be in the same folder!

% Gas constant (J/kmol-K):
R = c.R * 1e3;

% Molar mass of H2 (kg/kmol):
M = 0.00201588 * 1e3;

% Room temperature (K):
Tmix_K = c.C_to_K(30);

% Gas temperature (K):
T_K = Tmix_K;

% Room pressure (Pa):
Pmix_Pa = 1 * c.atm_to_Pa;

% H2 density (kg/m3):
rho_H2 = 0.0809904013115987;

% H2 density NTP (kg/m3):
rho_H2_NTP = 0.0837521739094197;

% Conversion factor, kg/sec to Nl/min (NTP litre/min):
kg_sec_to_Nlitre_min = 1/rho_H2_NTP*1000*60;

% Conversion factor, kg/sec to Nm3/h (NTP m3/h):
kg_sec_to_Nm3_h = 1/rho_H2_NTP*60*60;

% Conversion factor, Nm3/h to kg/s:
Nm3_h_to_kg_s = c.m3_h_to_m3_sec * rho_H2_NTP;

% Electrolyzer max. production (flow rate), Nm3/h:
electrolyzer_flow_rate_Nm3_h = 0.64;

% Extractors, time constant (s):
tao_extractor_s = 2;

% Safety factor 'f' (according to NF 60079-10-1, equation C.1):
f = 3.0; % f = 1.5 for mildy inefficient mixing

% Container volume (m3):
V_container_m3 = 22.0;

% H2 reservor volume (m3):
V_H2_tank = 850 * c.L_to_m3;

% Initial reservoir pressure (bar):
P_reservoir_0_bar = 25;

% Tank pressure regulator (bar):
P_reg_reservoir_bar = 4;

% Max. electrolyzer pressure (bar)
P_electr_max_bar = 25;

% Container average horizontal surface (m2)
S_container_m2 = 2.3 * 4.5;

% Extractor, continuous air renewal (m3/h)
dV_renewal_m3_h = 460;

% Extractor, emergency (m3/h)
dV_emergency_m3_h = 2*1080;

% Alarm level (% of LIE)
alarm_H2_threshold_percent = 10; % 5.0

% LIE H2:
LIE_H2_vol_vol_percent = 4;
LIE_H2_vol_vol = LIE_H2_vol_vol_percent/100;
LIE_H2_ppm = LIE_H2_vol_vol * 1e6;
LIE_H2_kg_m3 = LIE_H2_vol_vol * rho_H2;

% Simulation end time (s):
Tend = 60*10;

%% Gamma and rho as a function of pressure (for flow rate computation)
% Gamma, rho and kappa vector (for real gas computation):
load ('./gamma_rho_kappa_vectors.mat')

%% Leak parameters
Cd = 0.75;
S_mm2 = 0.25; %0.10;

% Reservoir volume from where the leak is comming out(m3):
V_fc_m3 = 5 * c.L_to_m3; % fuel cell
V_electr_m3 = 1 * c.L_to_m3; % electrolyzer

% Initial electrolyzer pressure (bar):
P_electr_0_bar = 19;


